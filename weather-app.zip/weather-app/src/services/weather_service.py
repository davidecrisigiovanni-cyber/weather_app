from src.api.weather_api import fetch_weather

# database semplice città → coordinate
CITIES = {
    "roma": (41.9028, 12.4964),
    "milano": (45.4642, 9.1900),
    "napoli": (40.8518, 14.2681),
    "torino": (45.0703, 7.6869),
}

def get_weather_by_city(city_name):
    city_name = city_name.lower()

    if city_name not in CITIES:
        raise ValueError("Città non trovata nel database.")

    lat, lon = CITIES[city_name]
    data = fetch_weather(lat, lon)

    current = data["current_weather"]

    return {
        "temperature": current["temperature"],
        "windspeed": current["windspeed"],
        "weathercode": current["weathercode"]
    }