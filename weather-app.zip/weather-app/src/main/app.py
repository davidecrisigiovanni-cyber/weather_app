from src.services.weather_service import get_weather_by_city
from src.ui.display import show_weather

def main():
    print("🌍 Weather App")
    city = input("Inserisci città (roma, milano, napoli, torino): ")

    try:
        weather = get_weather_by_city(city)
        show_weather(city, weather)

    except ValueError as e:
        print("❌ Errore:", e)
    except Exception as e:
        print("⚠️ Errore generico:", e)

if __name__ == "__main__":
    main()